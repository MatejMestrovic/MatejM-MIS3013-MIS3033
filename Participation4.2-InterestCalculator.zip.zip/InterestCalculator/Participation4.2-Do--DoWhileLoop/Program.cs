﻿//Matej Mestrovic OU ID:113473064
//MIS-3013-995
using System;

namespace Participation4._2_Do__DoWhileLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            double userBalance;
            int compoundingYears;
            double intRate;

            //Write title
            Console.WriteLine("--- Interest Calculator --- \n\r");

            Console.WriteLine("This program will give you your projected account balance\n\r");

            //Asking about user's balance
            Console.WriteLine("What is your current balance >>>");
            bool userInput1 = double.TryParse(Console.ReadLine(), out userBalance);

            if (userInput1 == false)
            {
                Console.WriteLine("Only input numerical values. Try again!");
                if (double.TryParse(Console.ReadLine(), out userBalance) == false)
                {
                    Console.WriteLine("Answer is wrong, again. Press any key to exit the program!");
                    Console.ReadKey();
                    return;
                }
            }


            Console.WriteLine("How many years will it be compounded >>>");
            bool userInput2 = Int32.TryParse(Console.ReadLine(), out compoundingYears);

            if (userInput2 == false)
            {
                Console.WriteLine("Only input numerical values and whole numbers. Try again!");
                if (Int32.TryParse(Console.ReadLine(), out compoundingYears) == false)
                {
                    Console.WriteLine("Answer is wrong, again. Press any key to exit the program!");
                    Console.ReadKey();
                    return;
                }
            }

            Console.WriteLine("What is the interest rate >>>");
            bool userInput3 = double.TryParse(Console.ReadLine(), out intRate);

            if (userInput3 == false)
            {
                Console.WriteLine("Only input numerical values. Try again!");
                if (double.TryParse(Console.ReadLine(), out intRate) == false)
                {
                    Console.WriteLine("Answer is wrong, again. Press any key to exit the program!");
                    Console.ReadKey();
                    return;
                }
            }

            int Time = 1;

            while (Time <= compoundingYears)
            {
                userBalance = userBalance * intRate;
                Time++;
                Console.WriteLine($"\nThe balance is {userBalance:C2}");
            }

            Console.ReadKey();

        }
    }
}
