﻿//Matej Mestrovic  OUID:113473064
//MIS 3013

using System;
using System.Collections.Generic;

namespace Participation12._2_InterestCalculatorWithFunctions
{
    class Program
    {
        static double InterestRate;
        static void Main(string[] args)
        {
            DisplayHeader();

            Console.WriteLine("\r\nPlease enter number for your interest rate (ex. 0.057):");
            Program.InterestRate = ValidateNumber(Console.ReadLine());

            

            List<double> numbers = new List<double>();


            Console.WriteLine("\r\nWhat is your current account balance?");
            numbers.Add(ValidateNumber(Console.ReadLine()));

            Console.WriteLine("How many years will your balance be compounded?");
            numbers.Add(ValidateNumber(Console.ReadLine()));


            Console.WriteLine("\r\nTo exit press any key");
            Console.ReadKey();

        }


       



         static double ValidateNumber(string input)
         {
            bool isNumber = false;
            double validNum;
            do
            {
                isNumber = double.TryParse(input, out validNum);

                if (!isNumber)
                {
                    Console.WriteLine("Please enter a valid number");
                }
            } while (!isNumber);
            return validNum;
         }

        static void DisplayHeader()
        {
            string title = " --- Interest Calculator With Functions --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);

            Console.WriteLine(title);
        }
    }
}
