﻿//Matej Mestrovic OU ID:113473064
//MIS3013-995

using System;

namespace Participation4._1_RandomClass
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("--- Guess a number ---\n\r");
            Console.WriteLine("Pick a number between 1 and 10");
            bool isNum = Int32.TryParse(Console.ReadLine(), out int userGuess);
            if (isNum)
            {

                Random random = new Random();
                int randomNumber = random.Next(1, 10);
                if (userGuess == randomNumber)
                {

                    Console.WriteLine($"Great guess! {userGuess} was correct!");
                }
                else
                {

                    Console.WriteLine("You get one more try");
                    Console.WriteLine("Pick a number between 1 and 10");
                    isNum = Int32.TryParse(Console.ReadLine(), out userGuess);
                    if (userGuess == randomNumber)
                    {

                        Console.WriteLine($"Great guess! {userGuess} was correct!");
                    }
                    else
                    {

                        Console.WriteLine("Thanks for playing! Sorry you didn't guess correctly");
                    }
                }
            }
            else
            {
                Console.WriteLine("Sorry, that was not what was asked for");
            }
            Console.ReadKey();
            }
    }
}
