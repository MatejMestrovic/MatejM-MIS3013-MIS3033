﻿//Matej Mestrovic OUID:113473064
//MIS3013
//Final Exam due 12/5/2020 at 11:59pm
//Job application 
using System;
using System.Collections.Generic;

namespace JobApplicationConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //This is a console application for a job application with Acme Industries. 
            //The application should ask for personal information: First name, middle name, last name, address, city, state, zip code(5 digit), and phone number(10 digit).
            //Each of the following should be stored in a type of collection(all 3 types of collections must be used: dictionary, list, parallel arrays):
            //Education history information: School name and GPA
            //Work history information: Company and months worked at that company
            //References information: Full name of reference
            //Output all information and ask applicant to verify all of the information.If all is correct thank them, otherwise, start the application over.

            //this is how we output title in first row at the middle of screen
            string title = " --- MIS3013 Final Exam Part I --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            //list of state abreviation provided to us (also we have to use System.Collections.Generic)
            List<string> states = new List<string>() { "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI",
                                                       "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN",
                                                       "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH",
                                                       "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA",
                                                       "WV", "WI", "WY" };



            //variables that will be used in this program  to store first name, middle name, last name, addres, city, state, xip and phone
            string userLastName;
            string userFirstName;
            string userMiddleName;
            string userAddress;
            string userCity;
            string userState;
            int userZipCode = 0;
            long userPhoneNumber = 0;
            string userAnswer = " ";


            //we are required to ask user is all the data that they inputed correct, and to do this we have to use bool 
            bool isCorrect = false;
            //will be used to check if user inputed 5 numbers for ZipCode
            bool isTrue = false; 

            //we need to use loop in case data inputed is wrong so that user can do it all over again
            while (!isCorrect)
            {
                //ask user for their first name, Trim used to delete white space, and ToLower is user to trasform everything to lower case so it is easier to check it
                Console.WriteLine("\r\nWhat is your first name?");
                userFirstName = Console.ReadLine().Trim();
               

                //ask user for their middle name
                Console.WriteLine("\r\nWhat is your middle name? (if you use just one letter do not put period)");
                userMiddleName = Console.ReadLine().Trim();
               

                //ask user for their last name
                Console.WriteLine("\r\nWhat is your last name?");
                userLastName = Console.ReadLine().Trim();
               


                //ask user about their state they live in, also we need to make sure that user's answer is contained in the list (we assume that user is from USA and than we go lower asking what state than city, addres, zip and phone finally)
                while (!states.Contains(userAnswer))
                {
                    Console.WriteLine("\r\nWhat state do you live in? (Please enter your answer in following form; OK, TX, CA, NV,NE)");
                    userAnswer = Console.ReadLine().ToUpper().Trim();
                    
                }
                userState = userAnswer;

                //ask user in what city do they live
                Console.WriteLine("\r\nWhat is the name of city in which you live?");
                userCity = Console.ReadLine().Trim();
                

                //ask user where do they live - address
                Console.WriteLine("\r\nWWhat is your current address of living?");
                userAddress = Console.ReadLine().Trim();
                


                //ask user about their ZipCode, we will need to validate ZipCode using TryParse to make sure that user has inputed only 5 numbers, use if statement to check lenght
                while (!isTrue)
                {
                    Console.WriteLine("\r\nWhat is your ZipCode? (Please make sure you enter number that corresponds to your area, also make sure you only input numbers");
                    userAnswer = Console.ReadLine().Trim();
                    isTrue = Int32.TryParse(userAnswer, out userZipCode);
                    if (userAnswer.Length != 5)
                    {
                        isTrue = false;
                    }
                }
                isTrue = false;

                //ask user thier phone number, user TryParse to check if user only inputed numbers and use if statement to check did user input the 10 needed numbers
                while (!isTrue)
                {
                    Console.WriteLine("\r\nPlease enter your phone number: (plase make sure to enter just numbers [NOT (xxx)xxx-xxxx]");
                    userAnswer = Console.ReadLine().Trim();
                    isTrue = Int64.TryParse(userAnswer, out userPhoneNumber);
                    if (userAnswer.Length != 10)
                    {
                        isTrue = false;
                    }
                }
                isTrue = false;


                //Each of the following should be stored in a type of collection(all 3 types of collections must be used: dictionary, list, parallel arrays):
                //Education history information: School name and GPA, Work history information: Company and months worked at that company, 
                //References information: Full name of reference

                //use parallen arrays for schools and GPA
                double[] userGPA = new double[2];
                string[] userSchoolName = new string[2];

                //ask school info
                Console.WriteLine("\r\nWhat is the name of High School that you have attended?");
                userSchoolName[0] = Console.ReadLine().Trim();
                while (!isTrue)
                {
                    //ask for GPA in High School
                    Console.WriteLine($"\r\nWhat was your GPA at {userSchoolName[0]} high school?");
                    isTrue = Double.TryParse(Console.ReadLine().Trim(), out userGPA[0]);
                }
                isTrue = false;

                Console.WriteLine("\r\nWhat is the name of university that you have attended?");
                userSchoolName[1] = Console.ReadLine().Trim();
                while (!isTrue)
                {
                    //ask for GPA in High School
                    Console.WriteLine($"\r\nWhat was your GPA at {userSchoolName[1]} university?");
                    isTrue = Double.TryParse(Console.ReadLine().Trim(), out userGPA[1]);
                }
                isTrue = false;




                //dictionary for work history
                Dictionary<string, int> userCompanyAndMonths = new Dictionary<string, int>();

                //ask user to input information about company name and amount of months they spent working for the same company
                Console.WriteLine("\r\nWhat is the name of company that you have worked for?");
                string userCompanyName = Console.ReadLine().Trim();
                int userNumerOfMonthsWorked = 0;
                while (!isTrue)
                {
                    //ask number of months user worked for company above
                    Console.WriteLine($"\r\nHow many months have you worked for {userCompanyName}?");
                    isTrue = Int32.TryParse(Console.ReadLine(), out userNumerOfMonthsWorked);
                }
                userCompanyAndMonths.Add(userCompanyName, userNumerOfMonthsWorked);





                //create List<> for references that user will name
                List<string> userReferences = new List<string>();


                //ask user to input his references, ask for 2 references
                Console.WriteLine("\r\nWhat is the full name of your first reference?");
                string userReferenceOne = Console.ReadLine().Trim();

                Console.WriteLine("\r\nWhat is the full name of your second reference?");
                string userReferenceTwo = Console.ReadLine().Trim();

                userReferences.Add(userReferenceOne);
                userReferences.Add(userReferenceTwo);


                //output all the information that user has give and ask user is the information correct, if info is correct they will say yes and while loop will finish

                string output = "\r\n --- Output --- ";
                Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
                Console.WriteLine(output);

                Console.WriteLine($"\r\nUser full name: {userFirstName} {userMiddleName} {userLastName}");
                Console.WriteLine($"\r\nUser state: {userState}");
                Console.WriteLine($"\r\nUser City: {userCity}");
                Console.WriteLine($"\r\nUser Address: {userAddress}");
                Console.WriteLine($"\r\nUser ZipCode: {userZipCode}");
                Console.WriteLine($"\r\nUser Phone Number: {userPhoneNumber}");
                Console.WriteLine($"\r\nUser High School: {userSchoolName[0]} and GPA: {userGPA[0]}");
                Console.WriteLine($"\r\nUser University: {userSchoolName[1]} and GPA: {userGPA[1]}");

                foreach (KeyValuePair<string, int> pair in userCompanyAndMonths) Console.Write($"\r\nLast company worked: {pair.Key}, Time spend at company: {pair.Value} months");
                foreach (string userReference in userReferences) Console.WriteLine($"\r\nReference :{userReference}");

                //ask user is all the outputed data correct
                Console.WriteLine("\r\nIs the output of information correct? (Please answer Yes or No)");
                userAnswer = Console.ReadLine().Trim().ToUpper();
                if (userAnswer.Equals("YES"))
                {
                    isCorrect = true;
                }
            }
            Console.WriteLine("\r\nTo exit the program press any key!");
            Console.ReadKey();
        }
    }
}
