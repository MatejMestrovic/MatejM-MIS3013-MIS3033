﻿//Matej Mestrovic OU ID:113473064
//MIS-3013-995

using System;

namespace Participation_3._1
{
    class Program
    {
        const double MultiplicationConstant = 7.777;

        static void Main(string[] args)
        {
            Console.WriteLine("--Sum of 3 numbers--");


            Console.WriteLine("Please enetr a number >>>");
            double num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Please eneter another number >>>");
            double num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Please eneter final number >>>");
            double num3 = Convert.ToDouble(Console.ReadLine());

            double sum = num1 + num2 + num3;

            Console.WriteLine($"These numbers added together equal {sum:N3}");
            Console.WriteLine($"These numbers multiplied by the constant {MultiplicationConstant} is {(MultiplicationConstant * sum):N3}");

            Console.ReadKey();
        }
    }
}
