﻿//Matej Mestrovic OU ID: 113473064
//MIS 3013-995


using System;

namespace Participation_3._2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Hard coded title
            string HardCoded = "--If Statement--\n\r";
            Console.WriteLine(HardCoded);
            Console.WriteLine("What are we counting?");
            string userItem = Console.ReadLine();
            Console.WriteLine($"\n\rHow many {userItem} do you have?");
            int itemNumber = Convert.ToInt32(Console.ReadLine());
            if (itemNumber < 5)
            {
                Console.WriteLine($"\n\rThat's cool! Do you want to have more {userItem}!");
            }
            else
            {
                Console.WriteLine($"\n\rThat is too many {userItem} for one person.");

            }

            Console.ReadKey();
        }
    }
}
