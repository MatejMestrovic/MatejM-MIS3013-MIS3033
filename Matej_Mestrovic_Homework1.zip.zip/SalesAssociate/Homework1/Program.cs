﻿//Matej Mestrovic
// MIS 3033 - 900
//OU ID: 113473064
using System;

namespace Homework1
{
    class Program
    {
        const double cogsPrice = 79.99;
        const double gearsPrice = 250.00;
        const double markup1 = 1.15;
        const double markup2 = 1.125;
        const double salesTax = 1.089;

        static void Main(string[] args)
        {
            string title = " --- Sales Associate --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);          
            
            double standardAmount;
            double price;

            Console.WriteLine($"\n\rHow many cogs do you want to buy?");
            int cogsNum = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"\n\rHow many gears do you want to buy?");
            int gearsNum = Convert.ToInt32(Console.ReadLine());

            standardAmount = (cogsNum * cogsPrice + gearsNum * gearsPrice) * markup1;

            if (gearsNum+cogsNum >= 16 || gearsNum > 10 || cogsNum > 10)
            {
                price = (cogsNum * cogsPrice + gearsNum * gearsPrice) * markup2;
            }
            else
            {               
                price = (cogsNum * cogsPrice + gearsNum * gearsPrice) * markup1;
            }


            double discount;
            discount = (standardAmount - price);

            double totalAmount;
            totalAmount = (standardAmount - discount) * salesTax;



            //Output
            Console.WriteLine($"n\r You are buying cogs {cogsNum}.");
            Console.WriteLine($"n\r You are buying gears {gearsNum}.");
            Console.WriteLine($"n\r Your discount on amount is {discount}.");
            Console.WriteLine($"n\r Total value you are paying is {totalAmount}.");


            Console.ReadKey();
        }
    }
}
