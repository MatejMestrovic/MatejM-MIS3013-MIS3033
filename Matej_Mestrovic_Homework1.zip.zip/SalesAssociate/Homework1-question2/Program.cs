﻿//Question 2
/*Create an application that will keep prompting the user to input all 3 of their exam grades (using a For loop).  
Calculate the average of their exam scores and output the result.  
When you display the result, make sure to use a Format Specifier for percentages.*/
using System;
using System.Collections.Generic;


namespace Homework1_question2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            double[] array = new double[3];
            double sum = 0;

            Console.WriteLine("You will be asked to enter 3 exam  grades.\n\r");

            for (i = 0; i < array.Length; i++)
            {
                Console.WriteLine("\n\rWhat is your exam grades? (enter just a number without % sign, ex. 78.52)");
                array[i] = Convert.ToDouble(Console.ReadLine());
            }
            Console.WriteLine();

            for (i = 0; i < 3; i++) 
            {
                sum += array[i];
            }

            double average;
            average = (sum / array.Length);

            Console.WriteLine($"\n\rYour average grade is {average}%");
            Console.WriteLine("\n\rTo exit press any key!");
            Console.ReadKey();
        }
    }
}
