﻿//Matej Mestrovic (OU ID:113473064)
//MIS-3013-995
using System;

namespace Participation2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Hard coded title
            string hardCoded = "-- Input, Output, Converting, Formatting --\n\r";
            //This will output hard coded title
            Console.WriteLine(hardCoded);

            //Asking for a name
            Console.WriteLine("What is your name?");
            //Saving in string variable
            string name = Console.ReadLine();

            //Ask question about credit hours for current semester
            Console.WriteLine("\n\rHow many hours are you taking this semester?");
            //Save answer as int
            int hours = Convert.ToInt32(Console.ReadLine());

            //Ask question about favorite number
            Console.WriteLine("\n\rWhat is your favorite number");
            //Make the code save that value
            double number = Convert.ToDouble(Console.ReadLine());

            //Show all answers that user gave and use format specifier N2
            Console.WriteLine($"\n\r<Hit enter to confirm>");
            Console.WriteLine($"Your name is: " + name);
            Console.WriteLine($"You are taking:" + hours +  " hours");
            Console.WriteLine($"Your favorite number is (rounded to two decimal places):" + number.ToString("N2"));

            Console.ReadKey();
        }
    }
}
