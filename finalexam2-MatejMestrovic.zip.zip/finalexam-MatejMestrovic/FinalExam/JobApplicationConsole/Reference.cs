﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobApplicationConsole
{
    class Reference : Person //Person is a class inherited by both Reference and Applicant
    {
        private int YearsKnown;

        public void AddYearsKnown()
        {
            string userInp;

            bool isCorrect = false;

            while (!isCorrect)
            {
                Console.WriteLine($"\r\nHow long have you known your reference? (enter years)");
                userInp = Console.ReadLine().Trim();
                isCorrect = Int32.TryParse(userInp, out YearsKnown);
            }
            

        }
    }
}
