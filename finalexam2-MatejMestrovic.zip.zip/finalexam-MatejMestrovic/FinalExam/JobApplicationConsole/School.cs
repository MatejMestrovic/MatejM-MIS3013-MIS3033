﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobApplicationConsole
{
    class School
    {
        public string SchoolName;
        public string Degree;
        public double GPA;
        public bool MostRecentlyAttended;


        public School (string school)
        {
            SchoolName = school;
        }
          


        public School GetMostRecent(List<School> schools)
        {
            School recent = new School(" ");

            foreach (School school in schools)
            {
                if (school.MostRecentlyAttended == true)
                {
                    recent = school;
                }
            }
            return recent;
        }

    }
}
