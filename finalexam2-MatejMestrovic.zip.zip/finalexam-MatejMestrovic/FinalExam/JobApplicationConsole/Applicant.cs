﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobApplicationConsole
{
    class Applicant : Person  //Person is a class inherited by both Applicant and Reference
    {
        public string Address;
        public string City;
        public string State;
        public int ZipCode;

    }
}
