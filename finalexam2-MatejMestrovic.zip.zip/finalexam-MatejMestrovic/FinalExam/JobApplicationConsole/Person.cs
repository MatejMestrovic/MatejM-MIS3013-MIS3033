﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobApplicationConsole
{
    class Person
    {
        public string FirstName;
        public string MiddleName;
        public string LastName;
        public long PhoneNumber;
    }
}
