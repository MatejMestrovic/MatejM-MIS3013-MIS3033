﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobApplicationConsole
{
    class PreviousJob
    {
        public string CompanyName;
        public int MonthsWorked;
        public bool StillEmployeed; 
    }
}
