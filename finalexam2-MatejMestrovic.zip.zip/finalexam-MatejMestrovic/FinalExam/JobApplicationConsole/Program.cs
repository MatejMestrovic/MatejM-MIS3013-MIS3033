﻿//Matej Mestrovic OUID:113473064
//MIS3013
//Final Exam due 12/5/2020 at 11:59pm
//Job application 
using System;
using System.Collections.Generic;

namespace JobApplicationConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //Do not create a new solution and / or project.You will be reusing the same project from Part 1.
            //You will be refactoring, which just means changing it to work differently. 
            //Programming in the real world is an iterative process, and refactoring code is very common.
            //There will be 3 parts to the final exam.This portion will be due by Wednesday, December 9, at midnight. 
            //Part 2 will be refactoring your previous code into classes and making them more thorough.
            //Person is a base class inherited by both the Applicant class and the Reference class


            //this is how we output title in first row at the middle of screen
            string title = " --- MIS3013 Final Exam Part II --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            //list of state abreviation provided to us (also we have to use System.Collections.Generic)
            List<string> states = new List<string>() { "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI",
                                                       "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN",
                                                       "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH",
                                                       "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA",
                                                       "WV", "WI", "WY" };           
           

            
            string userAnswer = "";

            //we are required to ask user is all the data that they inputed correct, and to do this we have to use bool 
            bool isCorrect = false;
            
            bool isRight = false;
           
            //we need to use loop in case data inputed is wrong so that user can do it all over again
            while (!isCorrect)
            {

                Applicant user = new Applicant();
                //ask user for their first name, Trim used to delete white space, and ToLower is user to trasform everything to lower case so it is easier to check it
                Console.WriteLine("\r\nWhat is your first name?");
                user.FirstName = Console.ReadLine().Trim();

                
                //ask user for their middle name
                Console.WriteLine("\r\nWhat is your middle name? (if you use just one letter do not put period)");
                user.MiddleName = Console.ReadLine().Trim();
               

                //ask user for their last name
                Console.WriteLine("\r\nWhat is your last name?");
                user.LastName = Console.ReadLine().Trim();
               


                //ask user about their state they live in, also we need to make sure that user's answer is contained in the list (we assume that user is from USA and than we go lower asking what state than city, addres, zip and phone finally)
                while (!states.Contains(userAnswer))
                {
                    Console.WriteLine("\r\nWhat state do you live in? (Please enter your answer in following form; OK, TX, CA, NV,NE)");
                    userAnswer = Console.ReadLine().ToUpper().Trim();
                    
                }
                user.State = userAnswer;

                //ask user in what city do they live
                Console.WriteLine("\r\nWhat is the name of city in which you live?");
                user.City = Console.ReadLine().Trim();
                

                //ask user where do they live - address
                Console.WriteLine("\r\nWWhat is your current address of living?");
                user.Address = Console.ReadLine().Trim();
                


                //ask user about their ZipCode, we will need to validate ZipCode using TryParse to make sure that user has inputed only 5 numbers, use if statement to check lenght
                while (!isRight)
                {
                    Console.WriteLine("\r\nWhat is your ZipCode? (Please make sure you enter number that corresponds to your area, also make sure you only input numbers");
                    userAnswer = Console.ReadLine().Trim();
                    isRight = Int32.TryParse(userAnswer, out user.ZipCode);
                    if (userAnswer.Length != 5)
                    {
                        isRight = false;
                    }
                }
                isRight = false;
                

                //ask user thier phone number, user TryParse to check if user only inputed numbers and use if statement to check did user input the 10 needed numbers
                while (!isRight)
                {
                    Console.WriteLine("\r\nPlease enter your phone number: (plase make sure to enter just numbers [NOT (xxx)xxx-xxxx]");
                    userAnswer = Console.ReadLine().Trim();
                    isRight = Int64.TryParse(userAnswer, out user.PhoneNumber);
                    if (userAnswer.Length != 10)
                    {
                        isRight = false;
                    }
                }
                isRight = false;




                int schoolNumber = 0;
                List<School> schools = new List<School>();
                while (schoolNumber < 3)
                {
                    Console.WriteLine("\r\nPlease enter the name of your most recent school! " +
                        "If you have no more schools to enter please enter EXIT");
                    userAnswer = Console.ReadLine().ToUpper().Trim();

                    if (!isRight.Equals("EXIT"))
                    {
                        School school = new School(userAnswer);
                        while (!isRight)
                        {
                            Console.WriteLine($"What degree did you acqurie at {school.SchoolName}");
                            userAnswer = Console.ReadLine().Trim();
                            userAnswer = school.Degree;

                            Console.WriteLine("\r\nWhat GPA did you get?");
                            isRight = Double.TryParse(Console.ReadLine().Trim(), out school.GPA);
                        }

                        isRight = false;


                        while (!isRight)
                        {
                            Console.WriteLine("\r\nIs your shool the most recent one? (Answer with Yes or No)");
                            userAnswer = Console.ReadLine().ToUpper().Trim();
                            if (userAnswer.Equals("YES"))
                            {
                                school.MostRecentlyAttended = true;
                                isRight = true;
                            }
                            else if (userAnswer.Equals("NO"))
                            {
                                school.MostRecentlyAttended = false;
                                isRight = true;
                            }
                            else
                            {
                                Console.WriteLine("\r\nYour input has incorrect type of data, please try again!");
                            }
                        }
                        isRight = false;
                        schools.Add(school);
                        schoolNumber++;
                    }
                    else if (schoolNumber < 1)
                    {
                        Console.WriteLine("\r\nYou will have to enter at least one school");
                    }
                    else
                    {
                        schoolNumber = 3;
                    }

                }
                    int refNumber = 0;
                    List<Reference> references = new List<Reference>();

                    while (refNumber < 3)
                    {
                        Console.WriteLine("\r\nPlease enter the first name of your reference! " +
                            "If you have no more refernces to enter please enter EXIT");
                        userAnswer = Console.ReadLine().ToUpper().Trim();

                        if (!isRight.Equals("EXIT"))
                        {
                            Reference reference = new Reference();
                            userAnswer = reference.FirstName;

                            Console.WriteLine("\r\nPlease entere the middle name of your reference:");
                            reference.MiddleName = Console.ReadLine().Trim();

                            Console.WriteLine("\r\nPlease entere the last name of your reference:");
                            reference.LastName = Console.ReadLine().Trim();

                            while (!isRight)
                            {
                                Console.WriteLine("\r\nPlease enter refernce phone number: (plase make sure to enter just numbers [NOT (xxx)xxx-xxxx]");
                                userAnswer = Console.ReadLine().Trim();
                                isRight = Int64.TryParse(userAnswer, out reference.PhoneNumber);
                                if (userAnswer.Length != 10)
                                {
                                    isRight = false;
                                }
                            }
                            isRight = false;
                            references.Add(reference);
                            refNumber++;
                        }
                        else if (refNumber < 1)
                        {
                            Console.WriteLine("\r\nYou will have to enter at least one reference");
                        }
                        else
                        {
                            refNumber = 3;
                        }
                    }





                  PreviousJob previousJob = new PreviousJob();
                 List<PreviousJob> previousJobs = new List<PreviousJob>();

                Console.WriteLine("\r\nWhat is your lates company of employment?");
                previousJob.CompanyName = Console.ReadLine().Trim();


                while (!isRight)
                {
                    Console.WriteLine($"\r\nAre you still employeed at company {previousJob.CompanyName} that you have listed? (Answer with Yes or No)");
                    userAnswer = Console.ReadLine().ToUpper().Trim();
                    if (userAnswer.Equals("YES"))
                    {
                        previousJob.StillEmployeed = true;
                        isRight = true;
                    }
                    else if (userAnswer.Equals("NO"))
                    {
                        previousJob.StillEmployeed = false;
                        isRight = true;
                    }
                    else
                    {
                        Console.WriteLine("\r\nInformation you have entered is in incorrect format plese try again!");
                    }
                }
                isRight = false;
                previousJobs.Add(previousJob);
             
                while (!isRight)
                {
                    Console.WriteLine($"\r\nHow many months have you been working for {previousJob.CompanyName}?");
                    userAnswer = Console.ReadLine().Trim();
                    isRight = Int32.TryParse(userAnswer, out previousJob.MonthsWorked);
                }
                isRight = false;



                //output all the information that user has give and ask user is the information correct, if info is correct they will say yes and while loop will finish

                    string output = "\r\n --- Output --- ";
                    Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
                    Console.WriteLine(output);

                //output all info provided by user about themselves

                Console.WriteLine($"\r\nAplicant firs name: {user.FirstName}");
                Console.WriteLine($"\r\nAplicant middle name: {user.MiddleName}");
                Console.WriteLine($"\r\nAplicant last name: {user.LastName}");
                Console.WriteLine($"\r\nAplicant phone number: {user.PhoneNumber}");


                foreach (Reference refer in references)
                {
                    Console.Write($"\r\nRefernce full name is: {refer.FirstName} {refer.MiddleName} {refer.LastName}, and their contact number is {refer.PhoneNumber}");
                    
                }




                School MostRecentlyAttended = new School("");
                MostRecentlyAttended = MostRecentlyAttended.GetMostRecent(schools);

                Console.WriteLine($"\r\nThe most recent school applicant attended: {MostRecentlyAttended.SchoolName}");
                Console.WriteLine($"\r\nApplicant's GPA at {MostRecentlyAttended.SchoolName}: {MostRecentlyAttended.GPA}");

                foreach (PreviousJob prevJob in previousJobs)
                {
                    Console.WriteLine($"\r\nApplicant's latest company is {previousJob.CompanyName}");
                    if (prevJob.StillEmployeed)
                    {
                        Console.WriteLine($"\r\nApplicant is at the company for {previousJob.MonthsWorked} months.");
                    }
                }
                Console.WriteLine("\r\nTo exit the program press any key!");
                Console.ReadKey();
            }
        }
    }
}
