﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Participation_13._2___Bird_Classes
{
    //CalculateUnderwater( ) - The formula to calculate the time underwater is UM = (Height * Weight) / 1860

    class Penguin:Bird
    {
        public double SwimDepthMax;
        public double UnderwaterMinutes;

        public double Height;
        public double Weight;
        

        public double CalculateUnderwater()
        {
            return (Height * Weight) / 1860;
        }
    }
}
