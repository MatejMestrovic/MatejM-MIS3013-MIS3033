﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Participation_13._2___Bird_Classes
{
    //CalculateWingspan() - The formula to calculate the wingspan is WS = Height* 1.67
    class Robin:Bird
    {
        public double FlightSpeed;
        public double Height;

        public double CalculateWingspan()
        {
            return Height * 1.67;
        }

    }
}
