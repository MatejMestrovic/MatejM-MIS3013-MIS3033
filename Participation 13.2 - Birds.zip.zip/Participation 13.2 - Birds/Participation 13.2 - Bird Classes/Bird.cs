﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Participation_13._2___Bird_Classes
{
    class Bird
    {
        public double Height;
        public double Weight;
        public bool Gender;
        public int EggCount;

        public void LayEggs(int birdType)
        {
            if (Gender == false) //male
            {
                EggCount = 0;
            }
            else
            {
                if (birdType == 0) //penguin
                {
                    Random random = new Random();
                    EggCount = random.Next(0, 3);
                }
                else //robin
                {
                    Random random = new Random();
                    EggCount = random.Next(0, 5);
                }
            }

            
            Console.WriteLine($"Egg count: {EggCount}");

            return;
        }
    }
}
