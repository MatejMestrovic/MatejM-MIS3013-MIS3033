﻿//Matej Mestrovic  OUID: 113473064
//MIS3013

using System;

namespace Participation_13._2___Bird_Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = "---Bird Classes---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            //Bird bird1 = new Bird();
            //bird1.Height = 9;
            //bird1.Weight = 18;
            

            //Bird bird2 = new Bird();
            //bird2.Height = 4;
            //bird2.Weight = 11;


            Penguin penguin1 = new Penguin();
            penguin1.Height = 44;
            penguin1.Weight = 640;
            

            Penguin penguin2 = new Penguin();
            penguin2.Height = 47;
            penguin2.Weight = 662;


            Robin robin1 = new Robin();
            robin1.Height = 9;

            Robin robin2 = new Robin();
            robin2.Height = 9.5;

            Console.WriteLine("\r\nWhat is the gender of penguin1? (0 = male, 1 = female)");
            int penguin1Gender = Int32.Parse(Console.ReadLine());
            if (penguin1Gender == 0)
            {
                penguin1.Gender = false;
            }
            else
            {
                penguin1.Gender = true;
            }
            Console.WriteLine($"\r\nPenguin 1 time under water: {penguin1.CalculateUnderwater()}");
            penguin1.LayEggs(0);

            Console.WriteLine("\r\nWhat is the gender of penguin2? (0 = male, 1 = female)");
            int penguin2Gender = Int32.Parse(Console.ReadLine());
            if (penguin1Gender == 0)
            {
                penguin2.Gender = false;
            }
            else
            {
                penguin2.Gender = true;
            }
            Console.WriteLine($"Penguin 2 time uneder water: {penguin2.CalculateUnderwater()}");
            penguin2.LayEggs(0);



            Console.WriteLine("\r\nWhat is the gender of robin 1? (0 = male, 1 = female)");
            int robin1Gender = Int32.Parse(Console.ReadLine());
            if (penguin1Gender == 0)
            {
                robin1.Gender = false;
            }
            else
            {
                robin1.Gender = true;
            }
            Console.WriteLine($"\r\nRobin 1 wingspan: {robin1.CalculateWingspan()}");
            robin1.LayEggs(1);




            Console.WriteLine("\r\nWhat is the gender of robin 2? (0 = male, 1 = female)");
            int robin2Gender = Int32.Parse(Console.ReadLine());
            if (penguin1Gender == 0)
            {
                robin2.Gender = false;
            }
            else
            {
                robin2.Gender = true;
            }
            Console.WriteLine($"Robin 2 wingspan: {robin2.CalculateWingspan()}");
            robin2.LayEggs(1);



            Console.WriteLine("\r\nTo exit press any key!");
            Console.ReadKey();
        }
    }
}
