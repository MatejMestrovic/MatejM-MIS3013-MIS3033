﻿//Matej Mestrovic (OU ID: 113473064)
//MIS3013

using System;
using System.Reflection;

namespace Participation5._1_Multiples
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = "---Multiples---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            int countBy = 0;
            bool isNum = false;

            while (!isNum)
            {
                Console.WriteLine("What number would you like to count by?");
                isNum = Int32.TryParse(Console.ReadLine(), out countBy);
            }

            isNum = false;
            int UpTo = 0;

            while (!isNum)
            {
                Console.WriteLine("What number would you like to count up to?");
                isNum = Int32.TryParse(Console.ReadLine(), out UpTo);
            }

            int counter = 1;

            while (counter < UpTo)
            {
                if (counter % countBy == 0)
                {
                    Console.WriteLine(counter);
                }

                counter++;
            }
            Console.ReadKey();
        }
    }
}
