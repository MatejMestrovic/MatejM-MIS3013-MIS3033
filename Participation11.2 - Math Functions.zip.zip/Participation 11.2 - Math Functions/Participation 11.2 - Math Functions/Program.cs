﻿//Matej Mestrovic  OUID:113473064
//MIS3013

using System;

namespace Participation11.__MathFunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = " --- Math Functions --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);

            Console.WriteLine(title);

            string message = "Enter number that will be added to 100";
            double userInput = GetDoubleInput(message);
            Console.WriteLine($"{userInput} + 100 = {userInput + 100}");

            string message2 = "\r\nEnter number that will be substraceted from 100";
            double userInput2 = GetAddition(message2);
            Console.WriteLine($"100 - {userInput2} = {100 - userInput2}");

            string message3 = "\r\nEnter number that will be multiplied by 100";
            double userInput3 = GetMultiplication(message3);
            Console.WriteLine($"100 * {userInput3} = {100 * userInput3}");

            string message4 = "\r\nEnter number that will be devided by 100";
            double userInput4 = GetMultiplication(message4);
            Console.WriteLine($"{userInput4} / 100 = {userInput4 / 100}");

            Console.WriteLine("\r\nTo exit program press any key");
            Console.ReadKey();
        }

        static double GetDoubleInput (string messageToUser)
        {
            bool isNumber = false;
            double userInput = 0;
            do
            {
                Console.WriteLine(messageToUser);
                isNumber = double.TryParse(Console.ReadLine(), out userInput);
            } while (!isNumber);
            return userInput;
           
        }    
        static double GetAddition (string messageToUser2)
        {
        bool isNumber = false;
        double userInput2 = 0;
            do
            {
                Console.WriteLine(messageToUser2);
                isNumber = double.TryParse(Console.ReadLine(), out userInput2);
            } while (!isNumber);
            return userInput2;
        }
        
        static double GetMultiplication (string messageToUser3)
        {
            bool isNumber = false;
            double userInput3 = 0;
            do
            {
                Console.WriteLine(messageToUser3);
                isNumber = double.TryParse(Console.ReadLine(), out userInput3);
            } while (!isNumber);
            return userInput3;
        }

        static double GetDivison (string messageToUser4)
        {
            bool isNumber = false;
            double userInput4 = 0;
            do
            {
                Console.WriteLine(messageToUser4);
                isNumber = double.TryParse(Console.ReadLine(), out userInput4);
            } while (!isNumber);
            return userInput4;
        }
    }
}
