﻿//Matej Mestrovic  OU ID: 113473064
//MIS 3013

using System;
using System.Collections.Generic;

namespace Participation9._1_TopEarners
{
    class Program
    {
        static void Main(string[] args)
        {
            /*  1. Create parallel arrays, one will have salespeople first names and the other will hold last names. 

                2. Ask the user to input 3 for each, store them in the arrays. 

                3. Then create a list to hold the yearly earnings of that each salesperson, and ask the user to input each of those amounts

                4. Then output the average of those salespeople earnings.
             */

            string title = "---Top Earners---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            string[] firstName = new string[3];
            string[] lastName = new string[3];

            Console.WriteLine("The top three earners in the company are:\n\r");
            for (int i = 0; i < firstName.Length; i++)
            {
                Console.WriteLine($"Salesperson {i + 1} first name: ");
                firstName[i] = Console.ReadLine().Trim(); 
                Console.WriteLine($"Salesperson {i + 1} last name: ");
                lastName[i] = Console.ReadLine().Trim();
            }

            List<double> thisYearsEarnings = new List<double>();
            for (int i = 0; i < firstName.Length; i++)
            {
                bool isNumber = false;
                double earnings;
                do
                {
                    Console.WriteLine($"\r\nWhat are {firstName[i]} {lastName[i]}'s earnings this year?");
                    isNumber = double.TryParse(Console.ReadLine(), out earnings);
                } while (!isNumber);

                thisYearsEarnings.Add(earnings);
            }

            double sum = 0;
            for (int i = 0; i < thisYearsEarnings.Count; i++)
            {
                sum += thisYearsEarnings[i];
            }

            Console.WriteLine($"\r\nAverage earning between these three salespeople is {sum / 3:C2}");


            Console.WriteLine("\r\nTo exit press any key.");
            Console.ReadKey();
        }
    }
}
