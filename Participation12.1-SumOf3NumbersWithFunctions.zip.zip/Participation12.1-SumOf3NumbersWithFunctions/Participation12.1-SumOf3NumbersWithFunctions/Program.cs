﻿//Matej Mestrovic   OUID: 113473064
//MIS3013

using System;
using System.Collections.Generic;

namespace Participation12._1_SumOf3NumbersWithFunctions
{
    
    class Program
    {
        static double GlobalVariable;
        static void Main(string[] args)
        {
            DisplayHeader();


            Console.WriteLine("\r\nPlease enter number for your Global Variable:");
            Program.GlobalVariable = ValidateNumber(Console.ReadLine());

            List<double> numbers = new List<double>();

            Console.WriteLine("\r\nPlease enter your first number:");
            numbers.Add(ValidateNumber(Console.ReadLine()));

            Console.WriteLine("\r\nPlease enter your second number:");
            numbers.Add(ValidateNumber(Console.ReadLine()));

            Console.WriteLine("\r\nPlease enter your third number:");
            numbers.Add(ValidateNumber(Console.ReadLine()));


            double sum = Add(numbers);
            Console.WriteLine($"\r\nSum of your 3 numbers is: {Add(numbers):N2}");
            Console.WriteLine($"\r\nResult of your 3 numbers multiplied by a {GlobalVariable} is: {GlobalVariable * Add(numbers):N2}");



            Console.WriteLine("\r\nTo exit program press any key.");
            Console.ReadKey();

        }

        static double Add(List<double> numbers)
        {
            double sum = 0;
            foreach (var number in numbers)
            {
                sum += number;
            }
            return sum;
        }

         static double ValidateNumber(string input)
         {
            bool isNumber = false;
            double validNum;
            do
            {
                isNumber = double.TryParse(input, out validNum);

                if (!isNumber)
                {
                    Console.WriteLine("Please enter a valid number");
                }
            } while (!isNumber);
            return validNum;
         }

        static void DisplayHeader()
        {
            string title = " ---Sum of 3 Numbers with Functions --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);

            Console.WriteLine(title);
        }
    }
}
