﻿//Matej Mestrovic OU ID:113473064
//MIS3013

using System;

namespace Participation7._1
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = " --- String Reversal --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            
            Console.WriteLine(title);

            Console.WriteLine("What is your favorite word or phrase?\n\r");
            
            string input = Console.ReadLine().ToUpper();
            
            Console.WriteLine("\n\rReversed is: ");

            for (int i = input.Length - 1; i >= 0; i--)
            {
                if (i == 0)
                {
                    Console.WriteLine(input[i]);
                }
                else
                {
                    Console.WriteLine(input[i] + " ");
                }
            }

            Console.WriteLine("\r\nPress any key to quit program");
            Console.ReadKey();
        }
    }
}
