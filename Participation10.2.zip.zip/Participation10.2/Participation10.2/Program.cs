﻿//Matej Mestrovic  OUID:113473064
//MIS3013

using System;
using System.Collections.Generic;


namespace Participation10._2
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = " --- Class Grade Collections --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);

            Console.WriteLine(title);
            
            string[] courseSubject = new string[3];
            string[] courseNo = new string[3];
            Dictionary<int, string> course = new Dictionary<int, string>();

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"Your course subject {i + 1}:");
                courseSubject[i] = Console.ReadLine().Trim();
                
            }

            for (int i = 0; i < courseSubject.Length; i++)
            {
                bool isNumber = false;
                int idNumber;
                do
                {
                    Console.WriteLine($"What is {courseSubject[i]}'s number?");
                    isNumber = int.TryParse(Console.ReadLine(), out idNumber);
                } while (!isNumber);
                course.Add(idNumber, courseSubject[i]);
            }

            List<double> coursegGrade = new List<double>();
            foreach (var cgrade in course)
            {
                bool isNumber = false;
                double grade;
                do
                {
                    Console.WriteLine($"What is {cgrade.Value}'grade?");
                    isNumber = double.TryParse(Console.ReadLine(), out grade);
                } while (!isNumber);
                coursegGrade.Add(grade);
            }

            




            Console.WriteLine("\r\nTo exit press any key!");
            Console.ReadKey();
        }
    }
}
