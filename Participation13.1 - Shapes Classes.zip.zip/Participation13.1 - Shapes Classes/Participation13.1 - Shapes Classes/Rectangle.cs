﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Participation13._1___Shapes_Classes
{
    class Rectangle
    {
        //CalculateArea() - The formula to calculate the area of a rectangle is A = Width* Length
        //CalculatePerimeter() - The formula to calculate the perimeter of a rectangle is P = 2(Length + Width)
        public double Lenght;
        public double Width;


        public double CalculatePerimeter()
        {
            return 2 * (Lenght * Width);
        }


        public double CalculateArea()
        {
            return Lenght * Width;
        }
    }
}
