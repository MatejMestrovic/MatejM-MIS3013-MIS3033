﻿//Matej Mestrovic OUID: 113473064
//MIS3013

using System;

namespace Participation13._1___Shapes_Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = "---Shapes Classes---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            Rectangle rectangle1 = new Rectangle();
            rectangle1.Lenght = 4;
            rectangle1.Width = 5;

            Rectangle rectangle2 = new Rectangle();
            rectangle2.Lenght = 10;
            rectangle2.Width = 12;


            Circle circle1 = new Circle();
            circle1.Radius = 5;

            Circle circle2 = new Circle();
            circle2.Radius = 10;


            Console.WriteLine($"\r\nRectangle 1 area: {rectangle1.CalculateArea()}");
            Console.WriteLine($"Rectangle 1 perimeter: {rectangle1.CalculatePerimeter()}");

            Console.WriteLine($"\r\nRectangle 2 area: {rectangle2.CalculateArea()}");
            Console.WriteLine($"Rectangle 2 perimeter: {rectangle2.CalculatePerimeter()}");

            Console.WriteLine($"\r\nCircle 1 area: {circle1.CalculateArea()}");
            Console.WriteLine($"Circle 1 perimeter: {circle1.CalculatePerimeter()}");

            Console.WriteLine($"\r\nCircle 2 area: {circle2.CalculateArea()}");
            Console.WriteLine($"Circle 2 perimeter: {circle2.CalculatePerimeter()}");


            Console.WriteLine("\r\nTo exit press any key!");
            Console.ReadKey();
        }
    }
}
