﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Participation13._1___Shapes_Classes
{
    class Circle
    {
        //CalculateArea() - The formula to calculate the area of a circle is A = π* Radius2
        //CalculatePerimeter() - The formula to calculate the perimeter of a circle is P = 2π* Radius
        public double Radius { get; set; }




        public double CalculatePerimeter()
        {
            return 2 * Math.PI * Radius;
        }


        public double CalculateArea()
        {
            return Math.PI * Math.Pow(Radius, 2);
        }
    }
}
