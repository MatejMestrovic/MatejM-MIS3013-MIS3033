﻿//Matej Mestrovic  OUID:113473064
//MIS3013

using System;

namespace Participation11._1_GetDoubleInput___Function
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = " --- GetDoubleInput() Function --- ";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);

            Console.WriteLine(title);

            string message = "Enter number that will be multilied by 5";
            double userInput = GetDoubleInput(message);
            Console.WriteLine($"\r\n{userInput} * 5 = {userInput * 5}");

            Console.WriteLine("\r\nTo exit program press any key");
            Console.ReadKey();
        }

        static double GetDoubleInput (string messageToUser)
        {
            bool isNumber = false;
            double userInput = 0;
            do
            {
                Console.WriteLine(messageToUser);
                isNumber = double.TryParse(Console.ReadLine(), out userInput);
            } while (!isNumber);
            return userInput;
           
        }      
    }
}
