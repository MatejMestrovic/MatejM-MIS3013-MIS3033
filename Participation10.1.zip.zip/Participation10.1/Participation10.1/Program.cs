﻿//Matej Mestrovic  OUID:113473064
//MIS3013

using System;
using System.Collections.Generic;

namespace Participation10._1
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = "---Top Earners---";
            Console.SetCursorPosition(Console.WindowWidth - title.Length / 2, Console.CursorTop);
            Console.WriteLine(title);

            string[] firstName = new string[3];
            string[] lastName = new string[3];
            Dictionary<int, string> salesPeople = new Dictionary<int, string>();

            Console.WriteLine($"Top three earners in the company are:\n\r");
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"Salesperson {i + 1} first name:");
                firstName[i] = Console.ReadLine().Trim();
                Console.WriteLine($"Salesperson {i + 1} last name:");
                lastName[i] = Console.ReadLine().Trim();
            }

            for (int i = 0; i < firstName.Length; i++)
            {
                bool isNumber = false;
                int idNumber;
                do
                {
                    Console.WriteLine($"What is {firstName[i]} {lastName[i]}'s ID number?");
                    isNumber = int.TryParse(Console.ReadLine(), out idNumber);
                } while (!isNumber);
                salesPeople.Add(idNumber, firstName[i] + lastName[i]);
            }

            List<double> thisYearEarnings = new List<double>();
            foreach (var person in salesPeople)
            {
                bool isNumber = false;
                double earning;
                do
                {
                    Console.WriteLine($"What are {person.Value}'s earnings this year?");
                    isNumber = double.TryParse(Console.ReadLine(), out earning);
                } while (!isNumber);
                thisYearEarnings.Add(earning);
            }

            double sum = 0;
            foreach (double earning in thisYearEarnings)
            {
                sum += earning;
            }

            Console.WriteLine($"Average earning between these three salespeople is {sum / 3:c2}");






            Console.WriteLine("\r\nTo exit press any key!");
            Console.ReadKey();
        }
    }
}
