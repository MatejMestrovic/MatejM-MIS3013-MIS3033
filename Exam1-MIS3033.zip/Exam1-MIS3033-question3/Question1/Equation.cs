﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Question1
{
    class Equation
    {
        public double Left { get; set; }
        public double Right { get; set; }


        public Equation()
        {
            Left = 0;
            Right = 0;
        }

        public Equation(double left, double right)
        {
            Left = left;
            Right = right;
        }

        public double Add()
        {
            double addition;
            addition = Left + Right;
            return addition;
        }

        public double Substract()
        {
            double substraction;
            substraction = Left - Right;
            return substraction;
        }

        public double Multiply()
        {
            double multiplication;
            multiplication = Left*Right;
            return multiplication;
        }

        public double LeftToThePower(int power)
        {
            power = (int)Right;
            double leftSidePower = Math.Pow(Left, power);
            return leftSidePower;
        }

        public double RightToThePower(int power)
        {
            power = (int)Left;
            double rightSidePower = Math.Pow(Right, power);
            return rightSidePower;
        }
    }
}
