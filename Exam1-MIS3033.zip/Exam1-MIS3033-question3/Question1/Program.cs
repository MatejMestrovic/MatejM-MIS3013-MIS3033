﻿//Matej Mestrovic  OUID: 113473064
//MIS3033
//Question 1 from Exam 1

using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = "--- Exam1 - Question1 ---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            Equation equa = new Equation();
            List<String> user = new List<string>();

            string answer;

            do
            {
                Console.WriteLine("\n\rYou will be asked to input values for left and right in the equation. " +
                "\nEx. Left + Right = x" +
                "\nYou will be asked about matehmatical operations too.\n\r");

                Console.WriteLine("Please write an input for the left side of the equation:");
                equa.Left = Convert.ToDouble(Console.ReadLine());


                Console.WriteLine("Please write an input for the right side of the equation:");
                equa.Right = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("\n\rWhat mathematical operation you want to use between Left and Right?" +
                    "\nYou can choose between: addition, substraction, multiplication and power on either left or right side." +
                    "\nTo choose Addition type in +" +
                    "\nTo choose Substraction type in -" +
                    "\nTo choose Multiplication type in *" +
                    "\nTo choose to find power of Left type in ^" +
                    "\nTo choose to find power of Right type in @");
                char userInput = Convert.ToChar(Console.ReadLine());

                if (userInput == '+')
                {
                    Console.WriteLine($"You have choosen matehmatical operation of addition.The sum of Left and Right side is: {equa.Add()}");
                }
                else if (userInput == '-')
                {
                    Console.WriteLine($"You have choosen matehmatical operation of substraction.The difference between Left and Right side is: {equa.Substract()}");
                }
                else if (userInput == '*')
                {
                    Console.WriteLine($"You have choosen matehmatical operation of multiplication.The product of Left and Right side is: {equa.Multiply()}");
                }
                else if (userInput == '^')
                {
                    Console.WriteLine($"You have choosen matehmatical operation of power. The Left {equa.Left} to the power of Right {equa.Right} is: {equa.LeftToThePower(power: (int)equa.Right)}");
                }
                else if (userInput == '@')
                {
                    Console.WriteLine($"You have choosen matehmatical operation of power. The Right {equa.Right} to the power of Left {equa.Left} is: {equa.RightToThePower(power: (int)equa.Left)}");
                }

                Console.WriteLine("\n\rWould you like to try again with different numbers? Answer with Y for yes or N for no!");
                answer = Console.ReadLine();

                if (answer == "N" || answer == "n")
                {
                    break;
                }
                
            } while (answer != "Y" || answer != "y");          

            Console.WriteLine("\n\rTo exit press any key!");
            Console.ReadKey();
        }        
    }
}
