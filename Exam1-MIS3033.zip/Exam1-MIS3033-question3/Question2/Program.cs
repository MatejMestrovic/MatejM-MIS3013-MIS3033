﻿//Matej Mestrovic  OUID: 113473064
//MIS3033
//Question 2 of exam 1

using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Console;

namespace Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = "--- Exam1 - Question2 ---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);


            const double espresso = 2.15;
            const double cappuccino = 4.20;
            const double latte = 5.00;
            const double americano = 3.55;
            const double drip = 1.15;
            const double vanillaShot = 0.75;
            const double espressoShot = 0.80;
            const double salesTax = 0.075;
            double total = 0;
            double userInput5;
            double extraShotTotal = 0;
            double finalTotal = 0;
            double finalTotalWithTax = 0;
            string userInput4;

            //user says hello to open interface
            Console.WriteLine("");
            string userInput = Console.ReadLine();

            if (userInput == "hello" || userInput == "Hello" || userInput == "hi" || userInput == "hey")
            {
                Console.WriteLine("Wellcome to our coffee shop! The menu wil be outputed to you and you can choose your drink.\n\r");
            }

            string title2 = "--- Beverage Menu ---";
            Console.SetCursorPosition((Console.WindowWidth - title2.Length) / 2, Console.CursorTop);
            Console.WriteLine(title2);

            Console.WriteLine("Espresso = 2.15" +
                "\nCappuccino = 4.20" +
                "\nLatte = 5.00" +
                "\nAmericano = 3.55" +
                "\nDrip = 1.15");

            Console.WriteLine("Choose one of the beverages above:");
            string userInput2 = Console.ReadLine().ToLower();

            if (userInput2 == "espresso")
            {
                total = espresso;
            }
            else if (userInput2 == "cappuccino")
            {
                total = cappuccino;
            }
            else if (userInput2 == "latte")
            {
                total = latte;
            }
            else if (userInput2 == "americano")
            {
                total = americano;
            }
            else if (userInput2 == "drip")
            {
                total = drip;
            }
            else
            {
                Console.WriteLine("Your input was incorrect. Please try again.");
            }

            Console.WriteLine("Would you like any extra additons to your drink?  (Answer with Yes or No)");
            string userInput3 = Console.ReadLine().ToLower();

            if (userInput3 == "yes" || userInput3 == "y")
            {
                string title3 = "--- Extras Menu ---";
                Console.SetCursorPosition((Console.WindowWidth - title3.Length) / 2, Console.CursorTop);
                Console.WriteLine(title3);

                Console.WriteLine("Vanilla = 0.75" +
                    "\nEspresso = 0.80");

                Console.WriteLine("What shot would you like?");
                userInput4 = Console.ReadLine().ToLower();

                Console.WriteLine("How many shots would you like?");
                userInput5 = Convert.ToDouble(Console.ReadLine());

                if (userInput4 == "vanilla")
                {
                    extraShotTotal = vanillaShot * userInput5;
                }
                else if (userInput4 == "espresso")
                {
                    extraShotTotal = espressoShot * userInput5;
                }
               
            }

            finalTotal = total + extraShotTotal;
            finalTotalWithTax = finalTotal + (finalTotal * salesTax);


            string title4 = "--- Output ---";
            Console.SetCursorPosition((Console.WindowWidth - title4.Length) / 2, Console.CursorTop);
            Console.WriteLine(title4);

            Console.WriteLine($"You have chosen {userInput2}."); 
            Console.WriteLine($"You total is {finalTotalWithTax} USD.");

            Console.WriteLine("To exit press any key!");
            Console.ReadKey();
        }
    }
}
