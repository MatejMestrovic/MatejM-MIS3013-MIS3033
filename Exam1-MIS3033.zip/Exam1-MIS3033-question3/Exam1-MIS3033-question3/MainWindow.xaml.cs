﻿using System;
using System.Windows;



namespace Exam1_MIS3033_question3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       

        public MainWindow()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            /*we first need to declare variables that will be used: first and last name of user, date of birth 
            and phone number*/

            string firstName = userFirstName.Text;
            string lastName = userLastName.Text;
            string dob = birthDatePicker.Text;
            


            //check did user input anything int boxes provided for first and last name

            if (string.IsNullOrEmpty(userFirstName.Text))
            {
                MessageBox.Show("Please don't live information blank!");
                userFirstName.Text = "";
            }
            

            if (string.IsNullOrEmpty(userLastName.Text))
            {
                MessageBox.Show("Please don'tl leave information blank!");
                userLastName.Text = "";
            }
           

            //check did user input integers for phone number, if there is a mistake notify user
            if (int.TryParse(userPhoneNumber.Text, out int phoneNumber))
            {
                Console.WriteLine("Please, just enter numbers!");
                userPhoneNumber.Text = "";
            }
            //my code works for a phone number of 9 digits, ot for one above

            //calculate user's age
            int userAge = (DateTime.Now.Year - DateTime.Parse(dob).Year) - 1;

            string m = "";
            m = $"{userLastName.Text} {userFirstName.Text}, {userAge}, ({dob}) {phoneNumber}";
            listBox.Items.Add(m);

            userFirstName.Clear();
            userLastName.Clear();
            userPhoneNumber.Clear();
            

        }

        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
