﻿//Matej Mestrovic (OU ID:113473064)
//MIS-3013-995

using System;

namespace Participation_2._1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Hard coded Variables
            string hardCoded = "-- C# Basics --\n\r";
            string myName = "Matej Mestrovic";
            int classHours = 16;
            DateTime currentDateTime = DateTime.Now;

            //This will output the hard coded title
            Console.WriteLine(hardCoded);
            //This string interpolation
            Console.WriteLine($"My name is {myName}, the current date and time is {currentDateTime}, and I am in {classHours} hours this semester\n\r");

            int firstInt = 1;
            int secondInt = 5;

            //This is standard concatenation 
            Console.WriteLine("My favorite number is " + firstInt + " and my second favorit number is " + secondInt + "\n\r");

            Console.WriteLine("We then use our binary operator +=\n\r");
            firstInt += secondInt;

            //Use precision specifier
            string formattedNumber = firstInt.ToString("D2");

            //Arguments method
            Console.WriteLine("And now the value of the first number formatted to show two digits is: {0}\n\nThis is equal to the original original value of the first plus the value of the second number", formattedNumber);


            Console.ReadLine();
        }
    }
}
