﻿//Matej Mestrovic  OU ID:113473064
//MIS3033

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2_Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            //give title at the center, string the title
            string title = "--- Question 2 ---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            //create dictionary and add elements to dictionary
            Dictionary<string, double> fruitANDprice = new Dictionary<string, double>();
            fruitANDprice.Add("apple", 0.99);
            fruitANDprice.Add("orange", 0.50);
            fruitANDprice.Add("banana", 0.50);
            fruitANDprice.Add("grape", 2.99);
            fruitANDprice.Add("blueberry", 1.99);

            //display fruits and their prices from dictionary to user so user can choose which one they want
            Console.WriteLine("Fruit  Price($)\n\r");
            foreach (KeyValuePair<string, double> fruit in fruitANDprice)
            {
                Console.WriteLine("{0}  {1}", fruit.Key, fruit.Value);
            }


            //ask user to enter their prefered fruit
            Console.WriteLine("\n\rPlease type in what is your prefered fruit:  (make sure you use small case letters like a, o, b, or g)");
            string userInput = Console.ReadLine();

            //check is user input contained in the Dictionary and if yes output the price for the fruit of their chhosing of not ask them to do it again
            if (fruitANDprice.ContainsKey(userInput))
            {
                Console.WriteLine("\n\rYou have chosen {0} at a price of ${1}.", userInput, fruitANDprice[userInput]);
            }
            else
            {
                Console.WriteLine("\n\rYou have either misspelled a fruit's name or entered a wrong fruit. Please try again!");
            }


            Console.WriteLine("To exit press any key!");
            Console.ReadKey();
        }
    }
}
