﻿//Matej Mestrovic  OU ID:113473064
//MIS3033

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = "--- Question 1 ---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            //create matching fruits and prices list
            String[] fruitName = { "apple", "orange", "banana", "grape", "blueberry" };
            double[] fruitPrice = { 0.99, 0.50, 0.50, 0.99, 1.99};


            //make it possible to display fruits and prices so user can see them
            Console.WriteLine("\n\rDisplay of Fruits and their Price (price is in USD)");

            for (int i = 0; i < fruitName.Length; i++)
            {
                Console.WriteLine($"\n\r{fruitName[i]} = {fruitPrice[i]}");
            }

            //ask user to enter their prefered fruit
            Console.WriteLine("\n\rPlease type in what is your prefered fruit:");
            string userInput = Console.ReadLine();

            //write code to check if user input is in the array, if not tell them they made mistake
            Boolean check = false;

            for (int i = 0; i < fruitName.Length; i++)
            {
                if (fruitName[i].Contains(userInput))
                {
                    check = true;
                    Console.WriteLine($"\n\rYou selected {fruitName[i]} at a price of {fruitPrice[i]} USD.");
                }
            }

            if (check == false)
            {
                Console.WriteLine("\n\rYour input is incorrect please try again!");
            }


            Console.WriteLine("\n\rTo exit press any key!");
            Console.ReadKey();

        }
    }
}
