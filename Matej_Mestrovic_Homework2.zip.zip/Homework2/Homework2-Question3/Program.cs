﻿//Matej Mestrovic   OU ID:113473064
//MIS3033

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Homework2_Question3
{
    class Program
    {
        static void Main(string[] args)
        {
            //give title at the center, string the title
            string title = "--- Question 3 ---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            int customerID;
            int cogNum;
            int gearNum;


            Console.WriteLine("Please enter customer ID:");
            customerID =int.Parse(Console.ReadLine());
            

            Console.WriteLine("Please enter number of cogs you wish to buy:");
            cogNum = int.Parse(Console.ReadLine());

            Console.WriteLine("Please enter number of gears you wish to buy:");
            gearNum = int.Parse(Console.ReadLine());


            Receipt receipt = new Receipt (customerID, cogNum, gearNum);
            receipt.printReceipt();


            Console.WriteLine("\n\rTo exit press any key!");
            Console.ReadKey();
        }
    }
}
