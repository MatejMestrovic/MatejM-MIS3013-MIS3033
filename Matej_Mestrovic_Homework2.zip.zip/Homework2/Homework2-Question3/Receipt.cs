﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Homework2_Question3
{
    class Receipt
    {
        private int customerID;
        private int cogNum;
        private int gearNum;
        private DateTime saleDate;
        public double cogPrice = 79.99;
        public double gearPrice = 250;
        

        public Receipt()
        {
            customerID = 0;
            cogNum = 0;
            gearNum = 0;
            saleDate = DateTime.Now;
        }

        public Receipt(int id, int cog, int gear)
        {
            customerID = id;
            cogNum = cog;
            gearNum = gear;
            saleDate = DateTime.Now;
        }

        public double calculateTotal()
        {
            double total = 0;
            if (cogNum > 10 || gearNum > 10 || cogNum + gearNum >= 16)
            {
                total = (cogNum * cogPrice + gearNum * gearPrice) * 1.125;
            }
            else
            {
                total = (cogNum * cogPrice + gearNum * gearPrice) * 1.15;
            }
            return total;         
        }

        public double calculateTaxValue()
        {
            double total = calculateTotal();
            double taxValue = 0;
            double tax = 0.089;

            taxValue = total * tax;

            return taxValue;
        }
        
        public double calculateNetValue()
        {
            double total = calculateTotal();
            double taxValue = calculateTaxValue();
            double netValue = 0;

            netValue = total + taxValue;
            return netValue;
        }

        public void printReceipt()
        {
            string title = "--- Output ---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            Console.WriteLine($"Customer ID:               {customerID}");
            Console.WriteLine($"Sale Date:                 {saleDate}");
            Console.WriteLine($"Cog Number:                {cogNum}");
            Console.WriteLine($"Gear Number:               {gearNum}");
            Console.WriteLine($"Total (only with markup):  {calculateTotal():C2}");
            Console.WriteLine($"Tax amount (tax on total): {calculateTaxValue():C2}");
            Console.WriteLine($"Net Value (total+tax):     {calculateNetValue():C2}");

        }
    }
}
