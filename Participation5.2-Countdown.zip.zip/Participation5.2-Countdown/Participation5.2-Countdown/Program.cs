﻿using System;

namespace Participation5._2_Countdown
{
    class Program
    {
        static void Main(string[] args)
        {
            string title = "---Multiples---";
            Console.SetCursorPosition((Console.WindowWidth - title.Length) / 2, Console.CursorTop);
            Console.WriteLine(title);

            int countdownby = 0;
            bool isNum = false;

            while (!isNum)
            {
                Console.WriteLine("What number would you like to count down by?");
                isNum = Int32.TryParse(Console.ReadLine(), out countdownby);
            }

            isNum = false;
            int startwith = 0;

            while (!isNum)
            {
                Console.WriteLine("What number would you like to start with?");
                isNum = Int32.TryParse(Console.ReadLine(), out startwith);
            }

            for (int i = startwith; i != 0; i--)
            {
                if (i % countdownby == 0)
                {
                    Console.WriteLine(i);
                }
            }
            Console.ReadKey();
        }
    }
}
